UC Top Up website starter

1. Open index.html in a browser to preview.
2. The listed UC quantities and prices are DEMO values. Edit the `packages` array in index.html before publishing.
3. This is a front-end starter only. It does NOT accept/verify payments, store orders on a server, connect to a real AI model, or deliver UC automatically.
4. For real automatic fulfillment you need a legitimate UC reseller/supplier API, a secure backend, order database, payment verification/webhook, and an AI API connected server-side. Never put secret API keys in index.html.
5. To publish publicly, buy/connect a domain and deploy the site using a static host (for example GitHub Pages, Netlify, or your hosting provider). Google indexing is not automatic; add a sitemap and submit the site in Google Search Console.
6. Confirm permission before displaying the Easypaisa account holder's name and number publicly. Do not collect passwords, OTPs, or card PINs.
